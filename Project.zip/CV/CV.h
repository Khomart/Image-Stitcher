#pragma once
#include "CV.h"

int main();